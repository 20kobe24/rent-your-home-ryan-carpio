import Image from 'next/image'

export default function Home() {
  return (
    <div className="text-rose-500 text-2xl">
      hello world!
    </div>
  )
}
